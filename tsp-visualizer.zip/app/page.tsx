import { Suspense } from "react"
import CitySelector from "@/components/city-selector"
import AlgorithmSelector from "@/components/algorithm-selector"
import ResultsPanel from "@/components/results-panel"
import MapVisualizer from "@/components/map-visualizer"
import ThreeDVisualizer from "@/components/three-d-visualizer"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { calculateRoute } from "@/lib/actions"

export default function Home() {
  return (
    <main className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">TSP Route Planner & Visualizer</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Calculate and visualize optimal routes between cities in Pakistan using various TSP algorithms
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Route Configuration</CardTitle>
                <CardDescription>Select cities and algorithm</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <form action={calculateRoute} className="space-y-6">
                  <CitySelector />
                  <AlgorithmSelector />
                  <Button type="submit" className="w-full">
                    Calculate Route
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Suspense fallback={<div className="h-[300px] flex items-center justify-center">Loading results...</div>}>
              <ResultsPanel />
            </Suspense>
          </div>

          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Route Visualization</CardTitle>
                <CardDescription>View the optimal route</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="2d" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="2d">2D Map</TabsTrigger>
                    <TabsTrigger value="3d">3D View</TabsTrigger>
                  </TabsList>
                  <TabsContent value="2d" className="h-[500px]">
                    <Suspense fallback={<div className="h-full flex items-center justify-center">Loading map...</div>}>
                      <MapVisualizer />
                    </Suspense>
                  </TabsContent>
                  <TabsContent value="3d" className="h-[500px]">
                    <Suspense
                      fallback={<div className="h-full flex items-center justify-center">Loading 3D view...</div>}
                    >
                      <ThreeDVisualizer />
                    </Suspense>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
