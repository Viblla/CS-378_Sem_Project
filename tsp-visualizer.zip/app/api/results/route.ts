import { NextResponse } from "next/server"

export async function GET() {
  try {
    // In a real implementation, you would fetch this from your database or state management
    // For now, we'll return mock data
    const results = {
      algorithms: [
        {
          name: "Nearest Neighbor",
          cost: 3245.7,
          time: 0.05,
        },
        {
          name: "Brute Force",
          cost: 3120.2,
          time: 2.45,
        },
        {
          name: "Held-Karp",
          cost: 3120.2,
          time: 0.85,
        },
      ],
    }

    return NextResponse.json(results)
  } catch (error) {
    console.error("Error fetching results:", error)
    return NextResponse.json({ error: "Failed to fetch results" }, { status: 500 })
  }
}
