import { writeFileSync } from 'fs';

// Create a FastAPI app to serve as an API for the Python TSP code
const fastApiCode = `
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import pandas as pd
import math
import time
import json
import os

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load city data
# Create a sample CSV if it doesn't exist
if not os.path.exists("pakistan_cities_coordinates.csv"):
    cities_data = [
        {"City": "Karachi", "Latitude": 24.8607, "Longitude": 67.0011},
        {"City": "Lahore", "Latitude": 31.5204, "Longitude": 74.3587},
        {"City": "Faisalabad", "Latitude": 31.4504, "Longitude": 73.135},
        {"City": "Rawalpindi", "Latitude": 33.6007, "Longitude": 73.0679},
        {"City": "Multan", "Latitude": 30.1798, "Longitude": 71.4214},
        {"City": "Hyderabad", "Latitude": 25.396, "Longitude": 68.3578},
        {"City": "Gujranwala", "Latitude": 32.1877, "Longitude": 74.1945},
        {"City": "Peshawar", "Latitude": 34.0151, "Longitude": 71.5249},
        {"City": "Quetta", "Latitude": 30.1798, "Longitude": 66.975},
        {"City": "Islamabad", "Latitude": 33.6844, "Longitude": 73.0479},
        {"City": "Sargodha", "Latitude": 32.074, "Longitude": 72.6861},
        {"City": "Sialkot", "Latitude": 32.4945, "Longitude": 74.5229},
        {"City": "Bahawalpur", "Latitude": 29.3956, "Longitude": 71.6722},
        {"City": "Sukkur", "Latitude": 27.7052, "Longitude": 68.857},
        {"City": "Jhang", "Latitude": 31.2655, "Longitude": 72.3168},
        {"City": "Sheikhupura", "Latitude": 31.7167, "Longitude": 73.985},
        {"City": "Larkana", "Latitude": 27.5598, "Longitude": 68.2264},
        {"City": "Gujrat", "Latitude": 32.5731, "Longitude": 74.075},
        {"City": "Mardan", "Latitude": 34.1989, "Longitude": 72.0231},
        {"City": "Kasur", "Latitude": 31.1187, "Longitude": 74.445},
    ]
    pd.DataFrame(cities_data).to_csv("pakistan_cities_coordinates.csv", index=False)

df = pd.read_csv("pakistan_cities_coordinates.csv")
df.dropna(subset=['Latitude', 'Longitude', 'City'], inplace=True)
df = df[df['Latitude'].apply(lambda x: isinstance(x, (int, float))) & df['Longitude'].apply(lambda x: isinstance(x, (int, float)))]
all_cities = df.to_dict(orient='records')

# Define request models
class RouteRequest(BaseModel):
    startCity: str
    selectedCities: List[str]
    algorithm: str

# TSP Algorithm implementations
def euclidean_distance(city1, city2):
    return math.hypot(city1["Longitude"] - city2["Longitude"], city1["Latitude"] - city2["Latitude"])

def build_distance_matrix(cities):
    n = len(cities)
    matrix = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            matrix[i][j] = euclidean_distance(cities[i], cities[j])
    return matrix

def nearest_neighbor(matrix, start=0):
    n = len(matrix)
    visited = [False]*n
    path = [start]
    visited[start] = True
    total_cost = 0
    current = start

    for _ in range(n - 1):
        next_city = min(
            [(i, matrix[current][i]) for i in range(n) if not visited[i]],
            key=lambda x: x[1]
        )[0]
        total_cost += matrix[current][next_city]
        path.append(next_city)
        visited[next_city] = True
        current = next_city

    total_cost += matrix[current][start]
    path.append(start)
    return path, total_cost

def brute_force_tsp(matrix):
    import itertools
    n = len(matrix)
    cities = list(range(n))
    min_cost = float('inf')
    best_path = []
    for perm in itertools.permutations(cities[1:]):
        current_path = [0] + list(perm) + [0]
        cost = sum(matrix[current_path[i]][current_path[i+1]] for i in range(n))
        if cost < min_cost:
            min_cost = cost
            best_path = current_path
    return best_path, min_cost

def held_karp(matrix):
    import itertools
    n = len(matrix)
    C = {}

    for k in range(1, n):
        C[(1 << k, k)] = (matrix[0][k], [0, k])

    for subset_size in range(2, n):
        for subset in itertools.combinations(range(1, n), subset_size):
            bits = 0
            for bit in subset:
                bits |= 1 << bit

            for k in subset:
                prev = bits & ~(1 << k)
                res = []
                for m in subset:
                    if m == k:
                        continue
                    res.append((C[(prev, m)][0] + matrix[m][k], C[(prev, m)][1] + [k]))
                C[(bits, k)] = min(res)

    bits = (2 ** n - 1) - 1
    res = []
    for k in range(1, n):
        res.append((C[(bits, k)][0] + matrix[k][0], C[(bits, k)][1] + [0]))
    cost, path = min(res)
    return path, cost

# API endpoints
@app.get("/")
def read_root():
    return {"message": "TSP Route Planner API is running"}

@app.post("/calculate-route")
async def calculate_route(request: RouteRequest):
    try:
        # Find the start city index
        start_city_index = next((i for i, city in enumerate(all_cities) if city["City"] == request.startCity), 0)
        
        # Filter cities based on selection
        selected_cities = [city for city in all_cities if city["City"] in [request.startCity] + request.selectedCities]
        
        if len(selected_cities) < 3:
            raise HTTPException(status_code=400, detail="At least 3 cities are required (start city + 2 destinations)")
        
        # Build distance matrix
        matrix = build_distance_matrix(selected_cities)
        
        # Run selected algorithm
        algorithm_name = ""
        results = []
        
        if request.algorithm == "nn" or request.algorithm == "all":
            start_time = time.time()
            path, cost = nearest_neighbor(matrix, start=0)  # Start city is always at index 0 in our filtered list
            elapsed = time.time() - start_time
            results.append({
                "name": "Nearest Neighbor",
                "cost": cost,
                "time": elapsed,
                "path": path
            })
            algorithm_name = "Nearest Neighbor"
        
        if request.algorithm == "bf" or request.algorithm == "all":
            if len(selected_cities) <= 10:  # Brute force is only feasible for small number of cities
                start_time = time.time()
                path, cost = brute_force_tsp(matrix)
                elapsed = time.time() - start_time
                results.append({
                    "name": "Brute Force",
                    "cost": cost,
                    "time": elapsed,
                    "path": path
                })
                algorithm_name = "Brute Force"
        
        if request.algorithm == "hk" or request.algorithm == "all":
            start_time = time.time()
            path, cost = held_karp(matrix)
            elapsed = time.time() - start_time
            results.append({
                "name": "Held-Karp",
                "cost": cost,
                "time": elapsed,
                "path": path
            })
            algorithm_name = "Held-Karp"
        
        if not results:
            raise HTTPException(status_code=400, detail="No valid algorithm selected or algorithm failed")
        
        # Sort results by cost (best algorithm first)
        results.sort(key=lambda x: x["cost"])
        
        # Return the best path and all algorithm results
        return {
            "cities": selected_cities,
            "algorithm": algorithm_name if request.algorithm != "all" else results[0]["name"],
            "path": results[0]["path"],
            "algorithms": results
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run with: uvicorn main:app --reload
`

// Write the FastAPI code to a file
writeFileSync('python-api/main.py', fastApiCode);

// Create a requirements.txt file for the Python dependencies
const requirementsTxt = `
fastapi==0.95.0
uvicorn==0.21.1
pandas==2.0.0
pydantic==1.10.7
`

writeFileSync('python-api/requirements.txt', requirementsTxt);

// Create a README.md file with instructions
const readmeMd = `
# TSP Route Planner API

This is a FastAPI backend for the TSP Route Planner and Visualizer.

## Setup

1. Install the required Python packages:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

2. Run the FastAPI server:
   \`\`\`
   uvicorn main:app --reload
   \`\`\`

3. The API will be available at http://localhost:8000

## API Endpoints

- GET / - Check if the API is running
- POST /calculate-route - Calculate the optimal route using the specified algorithm
`

writeFileSync('python-api/README.md', readmeMd);

console.log("Python API files created successfully!");
console.log("To run the API:");
console.log("1. Navigate to the python-api directory");
console.log("2. Install the required packages: pip install -r requirements.txt");
console.log("3. Start the server: uvicorn main:app --reload");
console.log("4. The API will be available at http://localhost:8000");
