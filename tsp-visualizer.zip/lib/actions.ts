"use server"

import { revalidatePath } from "next/cache"

export async function calculateRoute(formData: FormData) {
  try {
    // Extract data from the form
    const startCity = formData.get("startCity") as string
    const selectedCities = formData.getAll("selectedCities") as string[]
    const algorithm = formData.get("algorithm") as string

    // Call the Python API
    const response = await fetch("http://localhost:8000/calculate-route", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        startCity,
        selectedCities,
        algorithm,
      }),
    })

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`)
    }

    const result = await response.json()

    // Store the result in the server-side cache or database if needed
    // For now, we'll just revalidate the page
    revalidatePath("/")

    return { success: true, data: result }
  } catch (error) {
    console.error("Error calculating route:", error)
    return { success: false, error: (error as Error).message }
  }
}
