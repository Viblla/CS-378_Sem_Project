import { writeFileSync } from 'fs';

const integrationGuide = `
# TSP Route Planner and Visualizer Integration Guide

This guide explains how to integrate the Python backend with the Next.js frontend for the TSP Route Planner and Visualizer project.

## Project Structure

The project consists of two main parts:

1. **Next.js Frontend**: A web application that allows users to select cities, choose algorithms, and visualize the results.
2. **Python FastAPI Backend**: An API that implements the TSP algorithms and returns the results.

## Setup Instructions

### 1. Set Up the Python Backend

1. Navigate to the \`python-api\` directory:
   \`\`\`
   cd python-api
   \`\`\`

2. Install the required Python packages:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

3. Start the FastAPI server:
   \`\`\`
   uvicorn main:app --reload
   \`\`\`

4. The API will be available at http://localhost:8000

### 2. Set Up the Next.js Frontend

1. Install the required Node.js packages:
   \`\`\`
   npm install
   \`\`\`

2. Start the Next.js development server:
   \`\`\`
   npm run dev
   \`\`\`

3. The frontend will be available at http://localhost:3000

## How the Integration Works

1. When a user submits the form on the frontend, the \`calculateRoute\` server action in \`lib/actions.ts\` sends a POST request to the Python API at \`http://localhost:8000/calculate-route\`.

2. The Python API processes the request, runs the selected TSP algorithm, and returns the results.

3. The frontend displays the results in the Results Panel and visualizes the route on both the 2D map and 3D view.

## API Routes

The Next.js frontend includes two API routes that serve as a cache for the results:

1. \`/api/results\`: Returns the algorithm comparison results
2. \`/api/route\`: Returns the route data for visualization

In a production environment, you would want to store these results in a database or state management system.

## Customization

### Adding More Cities

To add more cities to the dataset:

1. Edit the \`pakistan_cities_coordinates.csv\` file in the Python API directory
2. Update the \`pakistanCities\` array in \`lib/data.ts\` in the Next.js frontend

### Adding More Algorithms

To add more TSP algorithms:

1. Implement the algorithm in the Python API
2. Add the algorithm option to the \`AlgorithmSelector\` component in the frontend

## Deployment

For production deployment:

1. Deploy the Python API to a server or serverless platform
2. Update the API URL in \`lib/actions.ts\` to point to your deployed API
3. Deploy the Next.js frontend to Vercel or another hosting platform

## Troubleshooting

- If you encounter CORS issues, make sure the Python API's CORS middleware is properly configured
- If the visualizations don't update, check the browser console for errors and ensure the API is returning the expected data format
`;

writeFileSync('integration-guide.md', integrationGuide);

console.log("Integration guide created successfully!");
console.log("The guide provides detailed instructions on how to integrate the Python backend with the Next.js frontend.");
