"use client"

import { useEffect, useRef, useState } from "react"
import { Canvas, useThree } from "@react-three/fiber"
import { OrbitControls, Text } from "@react-three/drei"
import * as THREE from "three"

function City({ position, name, isStart = false }) {
  return (
    <group position={position}>
      <mesh>
        <sphereGeometry args={[0.2, 32, 32]} />
        <meshStandardMaterial color={isStart ? "#ef4444" : "#0ea5e9"} />
      </mesh>
      <Text position={[0, 0.3, 0]} fontSize={0.2} color="#000000" anchorX="center" anchorY="middle">
        {name}
      </Text>
    </group>
  )
}

function Route({ points }) {
  const ref = useRef()

  useEffect(() => {
    if (ref.current && points.length > 1) {
      const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(p[0], p[1], p[2])))
      const geometry = new THREE.TubeGeometry(curve, 100, 0.05, 8, false)
      ref.current.geometry = geometry
    }
  }, [points])

  return (
    <mesh ref={ref}>
      <meshStandardMaterial color="#10b981" />
    </mesh>
  )
}

function Scene() {
  const [routeData, setRouteData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const { camera } = useThree()

  useEffect(() => {
    // Position camera
    camera.position.set(0, 10, 15)

    const fetchRouteData = async () => {
      try {
        const response = await fetch("/api/route")
        if (response.ok) {
          const data = await response.json()
          setRouteData(data)
        }
      } catch (error) {
        console.error("Error fetching route data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRouteData()
  }, [camera])

  if (loading || !routeData) {
    return (
      <>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
          <planeGeometry args={[30, 30]} />
          <meshStandardMaterial color="#f3f4f6" />
        </mesh>
        <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
      </>
    )
  }

  const { cities, path } = routeData

  // Convert lat/lng to 3D coordinates
  const scaleFactor = 10
  const centerLat = cities.reduce((sum: number, city: any) => sum + city.lat, 0) / cities.length
  const centerLng = cities.reduce((sum: number, city: any) => sum + city.lng, 0) / cities.length

  const cityPoints = cities.map((city: any) => {
    const x = (city.lng - centerLng) * scaleFactor * Math.cos((centerLat * Math.PI) / 180)
    const z = -(city.lat - centerLat) * scaleFactor
    return {
      name: city.name,
      position: [x, 0, z],
    }
  })

  const routePoints = path.map((cityIndex: number) => cityPoints[cityIndex].position)

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} />

      {/* Ground plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial color="#f3f4f6" />
      </mesh>

      {/* Cities */}
      {cityPoints.map((city, index) => (
        <City key={index} position={city.position} name={city.name} isStart={index === path[0]} />
      ))}

      {/* Route */}
      {routePoints.length > 0 && <Route points={routePoints} />}

      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
    </>
  )
}

export default function ThreeDVisualizer() {
  return (
    <div className="h-full w-full">
      <Canvas>
        <Scene />
      </Canvas>
    </div>
  )
}
