"use client"

import { useState } from "react"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function AlgorithmSelector() {
  const [algorithm, setAlgorithm] = useState("nn")

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Algorithm</Label>
        <RadioGroup
          defaultValue={algorithm}
          onValueChange={setAlgorithm}
          name="algorithm"
          className="flex flex-col space-y-1"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="nn" id="nn" />
            <Label htmlFor="nn" className="font-normal">
              Nearest Neighbor
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="bf" id="bf" />
            <Label htmlFor="bf" className="font-normal">
              Brute Force
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="hk" id="hk" />
            <Label htmlFor="hk" className="font-normal">
              Held-Karp
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="all" id="all" />
            <Label htmlFor="all" className="font-normal">
              Compare All
            </Label>
          </div>
        </RadioGroup>
      </div>
    </div>
  )
}
