"use client"

import { useState } from "react"
import { Check, ChevronsUpDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import { pakistanCities } from "@/lib/data"

export default function CitySelector() {
  const [open, setOpen] = useState(false)
  const [startCity, setStartCity] = useState("")
  const [selectedCities, setSelectedCities] = useState<string[]>([])

  const handleStartCitySelect = (city: string) => {
    setStartCity(city)
    setOpen(false)
  }

  const handleCityToggle = (city: string) => {
    setSelectedCities((prev) => (prev.includes(city) ? prev.filter((c) => c !== city) : [...prev, city]))
  }

  const handleRemoveCity = (city: string) => {
    setSelectedCities((prev) => prev.filter((c) => c !== city))
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="start-city">Starting City</Label>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between">
              {startCity ? startCity : "Select starting city..."}
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-full p-0">
            <Command>
              <CommandInput placeholder="Search city..." />
              <CommandList>
                <CommandEmpty>No city found.</CommandEmpty>
                <CommandGroup className="max-h-60 overflow-y-auto">
                  {pakistanCities.map((city) => (
                    <CommandItem key={city} value={city} onSelect={() => handleStartCitySelect(city)}>
                      <Check className={cn("mr-2 h-4 w-4", startCity === city ? "opacity-100" : "opacity-0")} />
                      {city}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
        <input type="hidden" name="startCity" value={startCity} />
      </div>

      <div className="space-y-2">
        <Label>Cities to Visit</Label>
        <div className="flex flex-wrap gap-2 mb-2">
          {selectedCities.map((city) => (
            <Badge key={city} variant="secondary" className="text-sm">
              {city}
              <button
                className="ml-1 text-muted-foreground hover:text-foreground"
                onClick={() => handleRemoveCity(city)}
              >
                ×
              </button>
              <input type="hidden" name="selectedCities" value={city} />
            </Badge>
          ))}
          {selectedCities.length === 0 && <div className="text-sm text-muted-foreground">No cities selected</div>}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {pakistanCities
            .filter((city) => city !== startCity)
            .map((city) => (
              <Button
                key={city}
                variant={selectedCities.includes(city) ? "default" : "outline"}
                size="sm"
                className="justify-start text-xs h-8"
                onClick={() => handleCityToggle(city)}
              >
                {city}
              </Button>
            ))}
        </div>
      </div>
    </div>
  )
}
