"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Clock, Route, Award } from "lucide-react"

export default function ResultsPanel() {
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const response = await fetch("/api/results")
        if (response.ok) {
          const data = await response.json()
          setResults(data)
        }
      } catch (error) {
        console.error("Error fetching results:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchResults()
  }, [])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Results</CardTitle>
          <CardDescription>Loading results...</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3 mx-auto"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!results || !results.algorithms || results.algorithms.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Results</CardTitle>
          <CardDescription>Calculate a route to see results</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8 text-muted-foreground">No results to display yet</CardContent>
      </Card>
    )
  }

  // Find the most efficient algorithm
  const bestAlgo = results.algorithms.reduce(
    (best: any, current: any) => (current.cost < best.cost ? current : best),
    results.algorithms[0],
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          Results
          <Badge className="ml-2 bg-green-600">
            <Award className="mr-1 h-3 w-3" />
            {bestAlgo.name}
          </Badge>
        </CardTitle>
        <CardDescription>Algorithm comparison</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {results.algorithms.map((algo: any) => {
          // Calculate efficiency percentage relative to the best algorithm
          const efficiency = (bestAlgo.cost / algo.cost) * 100

          return (
            <div key={algo.name} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-medium">{algo.name}</span>
                <span className="text-sm text-muted-foreground">{Math.round(efficiency)}% efficient</span>
              </div>
              <Progress value={efficiency} className="h-2" />
              <div className="flex justify-between text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Route className="mr-1 h-3 w-3" />
                  {algo.cost.toFixed(1)} units
                </div>
                <div className="flex items-center">
                  <Clock className="mr-1 h-3 w-3" />
                  {algo.time.toFixed(2)}s
                </div>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
