"use client"

import { useEffect, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import { Icon } from "leaflet"

// Fix for Leaflet marker icons in Next.js
const markerIcon = new Icon({
  iconUrl: "/marker-icon.png",
  iconRetinaUrl: "/marker-icon-2x.png",
  shadowUrl: "/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
})

export default function MapVisualizer() {
  const [routeData, setRouteData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRouteData = async () => {
      try {
        const response = await fetch("/api/route")
        if (response.ok) {
          const data = await response.json()
          setRouteData(data)
        }
      } catch (error) {
        console.error("Error fetching route data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRouteData()
  }, [])

  if (loading || !routeData) {
    // Center of Pakistan as default
    const center: [number, number] = [30.3753, 69.3451]

    return (
      <div className="h-full w-full rounded-md overflow-hidden border">
        <MapContainer center={center} zoom={5} style={{ height: "100%", width: "100%" }} scrollWheelZoom={true}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
        </MapContainer>
      </div>
    )
  }

  const { cities, path, algorithm } = routeData
  const routeCoordinates = path.map((cityIndex: number) => [cities[cityIndex].lat, cities[cityIndex].lng])
  const center: [number, number] = [
    cities.reduce((sum: number, city: any) => sum + city.lat, 0) / cities.length,
    cities.reduce((sum: number, city: any) => sum + city.lng, 0) / cities.length,
  ]

  return (
    <div className="h-full w-full rounded-md overflow-hidden border">
      <MapContainer center={center} zoom={5} style={{ height: "100%", width: "100%" }} scrollWheelZoom={true}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {cities.map((city: any, index: number) => (
          <Marker key={index} position={[city.lat, city.lng]} icon={markerIcon}>
            <Popup>{city.name}</Popup>
          </Marker>
        ))}

        <Polyline positions={routeCoordinates} color="#0ea5e9" weight={3} dashArray="5, 10" />
      </MapContainer>
    </div>
  )
}
